# Custom Highcharts "View Full Screen" Popup

This replaces Highcharts native browser fullscreen with a centered modal popup.

## Files

- `CommonChartFullscreen.tsx`
- `CommonChartFullscreen.css`

## Important integration note

Your existing `CommonChart.tsx` is the reusable component that builds the Highcharts options.

You currently have:

```ts
exporting: CHART_INTERACTION_OPTIONS.exporting
```

and your `CHART_INTERACTION_OPTIONS` contains:

```ts
menuItems: [
  'viewFullscreen',
  ...
]
```

For this custom behavior, remove `viewFullscreen` from that menu, because Highcharts native fullscreen will occupy the entire browser window.

Then add a custom expand button to your `CommonChart.tsx` itself, or use the wrapper component as shown in this example.

## Recommended integration into your existing CommonChart

The cleanest approach for your project is to put the popup logic directly into `CommonChart.tsx`.

1. Add:
```ts
const [isExpanded, setIsExpanded] = useState(false);
```

2. Import React state:
```ts
import { useState } from 'react';
```

3. Do NOT use the native:
```ts
'viewFullscreen'
```

4. Add your own expand button next to the chart.

5. When clicked:
```ts
setIsExpanded(true)
```

6. Render a fixed backdrop and centered modal when `isExpanded` is true.

The CSS in `CommonChartFullscreen.css` is ready to copy into your existing `CommonChart.css`.

## Size

The popup is currently:

```css
width: 60vw;
height: 60vh;
```

So it occupies approximately 60% of the browser window and is centered.

To make it larger:

```css
width: 70vw;
height: 70vh;
```

To make it smaller:

```css
width: 50vw;
height: 50vh;
```

The heading is outside the Highcharts plot area, so it remains visible in the popup.

The Close (×) button exits the popup immediately. Escape also closes it, and clicking the dimmed area outside the popup closes it.
