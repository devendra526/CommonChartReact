import React, { useEffect, useRef, useState } from 'react';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';

import './CommonChart.css';

type Props = {
  options: Highcharts.Options;
  title?: string;
};

/**
 * Use this wrapper around your existing Highcharts options.
 *
 * IMPORTANT:
 * Do NOT use Highcharts' native "viewFullscreen" menu item for this
 * custom popup behavior. Use the custom "Expand" button shown below.
 */
export default function CommonChartFullscreen({ options, title }: Props) {
  const [expanded, setExpanded] = useState(false);
  const chartRef = useRef<HighchartsReact.RefObject>(null);

  useEffect(() => {
    if (!expanded) return;

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setExpanded(false);
      }
    };

    document.addEventListener('keydown', onKeyDown);
    document.body.classList.add('chart-modal-open');

    return () => {
      document.removeEventListener('keydown', onKeyDown);
      document.body.classList.remove('chart-modal-open');
    };
  }, [expanded]);

  return (
    <>
      <div className="common-chart-wrapper">
        <button
          type="button"
          className="chart-expand-button"
          aria-label="View chart"
          title="View chart"
          onClick={() => setExpanded(true)}
        >
          ⛶
        </button>

        <HighchartsReact
          highcharts={Highcharts}
          options={options}
          ref={chartRef}
        />
      </div>

      {expanded && (
        <div
          className="chart-modal-backdrop"
          role="dialog"
          aria-modal="true"
          aria-label={title || 'Expanded chart'}
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) {
              setExpanded(false);
            }
          }}
        >
          <section className="chart-modal">
            <header className="chart-modal-header">
              <h2>{title || options.title?.text || ''}</h2>

              <button
                type="button"
                className="chart-modal-close"
                aria-label="Close chart"
                title="Close"
                onClick={() => setExpanded(false)}
              >
                ×
              </button>
            </header>

            <div className="chart-modal-content">
              <HighchartsReact
                highcharts={Highcharts}
                options={{
                  ...options,
                  chart: {
                    ...options.chart,
                    height: undefined,
                    backgroundColor: '#ffffff',
                  },
                }}
              />
            </div>
          </section>
        </div>
      )}
    </>
  );
}
