import {useMemo} from "react";
import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";
import Exporting from "highcharts/modules/exporting";
import ExportData from "highcharts/modules/export-data";
import Accessibility from "highcharts/modules/accessibility";
import FullScreen from "highcharts/modules/full-screen";
import type {CommonChartProps} from "./CommonChart.types";
import "./CommonChart.css";
Exporting(Highcharts); ExportData(Highcharts); Accessibility(Highcharts); FullScreen(Highcharts);
const base: Highcharts.Options={
 credits:{enabled:false},
 exporting:{enabled:true,buttons:{contextButton:{menuItems:["viewFullscreen","separator","downloadPNG","downloadJPEG","downloadPDF","downloadSVG","separator","downloadCSV","downloadXLS"]}}},
 tooltip:{shared:true,crosshairs:true}, chart:{animation:true,spacing:[16,16,16,16]}
};
export default function CommonChart({response,height=460,className="",loading=false,overrides,callback}:CommonChartProps){
 const options=useMemo<Highcharts.Options>(()=>({...base,...response,chart:{...base.chart,...response.chart,height},title:{text:undefined,...response.title},tooltip:{...base.tooltip,...response.tooltip},exporting:{...base.exporting,...response.exporting},...overrides}),[response,height,overrides]);
 return <div className={"common-chart "+className}><HighchartsReact highcharts={Highcharts} options={options} callback={callback}/>{loading&&<div className="common-chart__loading">Loading…</div>}</div>;
}