import type Highcharts from "highcharts";
export interface CommonChartResponse {
 chart?: Highcharts.ChartOptions; title?: Highcharts.TitleOptions; subtitle?: Highcharts.SubtitleOptions;
 xAxis?: Highcharts.XAxisOptions|Highcharts.XAxisOptions[]; yAxis?: Highcharts.YAxisOptions|Highcharts.YAxisOptions[];
 tooltip?: Highcharts.TooltipOptions; legend?: Highcharts.LegendOptions; plotOptions?: Highcharts.PlotOptions;
 exporting?: Highcharts.ExportingOptions; credits?: Highcharts.CreditsOptions; colors?: string[];
 responsive?: Highcharts.ResponsiveOptions; accessibility?: Highcharts.AccessibilityOptions;
 series: Highcharts.SeriesOptionsType[];
}
export interface CommonChartProps { response: CommonChartResponse; height?: number|string; className?: string; loading?: boolean; overrides?: Highcharts.Options; callback?: (chart: Highcharts.Chart)=>void; }