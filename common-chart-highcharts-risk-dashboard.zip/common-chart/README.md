# CommonChart — Highcharts Risk Dashboard Component

## Run
npm install
npm run dev

## Core principle
The backend response is intentionally close to `Highcharts.Options`. `series[].type` decides the chart type, and `series[].yAxis` can reference an axis index or axis id.

Example:
```json
{
  "yAxis":[{"id":"var"},{"id":"exposure","opposite":true}],
  "series":[
    {"type":"bar","name":"VaR","yAxis":"var","data":[18,22,20,25]},
    {"type":"line","name":"Exposure","yAxis":"exposure","data":[1.8,2,2.3,2.1]}
  ]
}
```

## Demo mocks
Line, column, horizontal bar, mixed multi-axis combo, stacked columns, area, scatter, pie, heatmap, gauge, bubble and X-range.

## Risk-tech defaults
Shared tooltip, crosshair, fullscreen, PNG/JPEG/PDF/SVG export, CSV/XLS export and accessibility are enabled.

## Extensibility
CommonChart accepts `Highcharts.SeriesOptionsType[]`, so it is not restricted to a fixed chart-type switch. Load any required Highcharts module once in the application entry point for module-specific series such as treemap, sankey, organization, wordcloud, etc.
