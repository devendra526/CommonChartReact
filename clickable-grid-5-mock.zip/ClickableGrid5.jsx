import React, { useState } from 'react';
import mockChildGridData from './mockChildGridData.json';
import './ClickableGrid5.css';

/*
 * Main flow:
 *
 * Main Grid
 *    |
 *    | click COB cell
 *    v
 * clicked value = "22 July 2026"
 *    |
 *    v
 * mockChildGridData["22 July 2026"]
 *    |
 *    v
 * 5 grid objects
 *    |
 *    v
 * childGrids.map(...)
 *
 * IMPORTANT:
 * This file intentionally keeps the click/map logic separate from
 * the actual AG Grid implementation. Replace renderGrid() below
 * with your existing renderGridPanel/CommonGrid function.
 */

const CLICKABLE_FIELD = 'cob';

const ClickableGrid5 = ({ mainGridData = [], mainColumnDefs = [] }) => {
  const [selectedValue, setSelectedValue] = useState(null);
  const [childGrids, setChildGrids] = useState([]);

  const handleMainGridCellClick = (params) => {
    if (params?.colDef?.field !== CLICKABLE_FIELD) {
      return;
    }

    // In your actual grid this will be the clicked COB value.
    const clickedValue = params.value;

    setSelectedValue(clickedValue);

    // Later replace this line with your API call.
    const gridsForSelectedValue = mockChildGridData[clickedValue] || [];

    setChildGrids(gridsForSelectedValue);
  };

  /*
   * This is the important MAP function.
   *
   * Every object returned for the selected COB is rendered as one grid.
   * If the API/mock returns 5 objects, exactly 5 grids are rendered.
   */
  const renderChildGrids = () => {
    return childGrids.map((grid, index) => (
      <div className="child-grid-panel" key={grid.id || index}>
        <div className="child-grid-title">
          {grid.title || `Grid ${index + 1}`}
        </div>

        {renderGrid(grid)}
      </div>
    ));
  };

  /*
   * Replace this function with your existing grid renderer.
   *
   * For example:
   *
   * return renderGridPanel({
   *   esTypeRiskClassTitle: grid.title,
   *   esTypeRiskClassGridData: grid,
   *   ...
   * });
   */
  const renderGrid = (grid) => {
    return (
      <div className="mock-grid">
        <div className="mock-grid-header">
          {grid.columns.map((parent) => (
            <div
              className="mock-parent-header"
              key={parent.field}
            >
              <div>{parent.headerName}</div>

              <div className="mock-child-header-row">
                {parent.children.map((child) => (
                  <div key={child.field}>
                    {child.headerName}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {grid.rows.map((row, rowIndex) => (
          <div className="mock-grid-row" key={rowIndex}>
            {row.cells.map((cell, cellIndex) => (
              <div className="mock-grid-cell" key={cellIndex}>
                {cell.value}
              </div>
            ))}
          </div>
        ))}
      </div>
    );
  };

  /*
   * DEMO ONLY:
   * This renders the main grid in a simple table.
   *
   * In your application, keep your existing AG Grid.
   * Just add:
   *
   * onCellClicked={handleMainGridCellClick}
   *
   * to your existing <AgGridReact />.
   */
  return (
    <div className="clickable-grid-5">
      <h3>Main Grid</h3>

      <div className="main-grid">
        <div className="main-grid-row main-grid-header">
          {mainColumnDefs.map((column) => (
            <div key={column.field}>
              {column.headerName}
            </div>
          ))}
        </div>

        {mainGridData.map((row, rowIndex) => (
          <div className="main-grid-row" key={rowIndex}>
            {mainColumnDefs.map((column) => {
              const isClickable =
                column.field === CLICKABLE_FIELD;

              return (
                <div
                  key={column.field}
                  className={
                    isClickable
                      ? 'main-clickable-cell'
                      : ''
                  }
                  onClick={() => {
                    if (isClickable) {
                      handleMainGridCellClick({
                        value: row[column.field],
                        data: row,
                        colDef: column,
                      });
                    }
                  }}
                >
                  {row[column.field]}
                </div>
              );
            })}
          </div>
        ))}
      </div>

      {selectedValue && (
        <div className="selected-value">
          Selected COB: <strong>{selectedValue}</strong>
        </div>
      )}

      <div className="child-grids-container">
        {renderChildGrids()}
      </div>
    </div>
  );
};

export default ClickableGrid5;
