# 5 Child Grid Mock Data

This version is based on the two screenshots supplied.

## Structure

Every child grid uses the SAME column structure:

- COB (parent)
  - COB Child 1
  - COB Child 2
  - COB Child 3
- PCOB (parent)
  - PCOB Child 1
  - PCOB Child 2
  - PCOB Child 3

The values are mock values based on the Excel screenshot.

## Main functionality

When the user clicks a COB value in the main grid:

```text
22 July 2026
      |
      v
mockChildGridData["22 July 2026"]
      |
      v
[Grid 1, Grid 2, Grid 3, Grid 4, Grid 5]
      |
      v
childGrids.map(...)
      |
      v
5 grids displayed
```

## Where to put your actual mock data

Edit:

`mockChildGridData.json`

The top-level key is the clicked value:

```json
{
  "22 July 2026": [
    {
      "id": "grid-1",
      "title": "Table 1 - IR",
      "columns": [...],
      "rows": [...]
    }
  ]
}
```

Add the other 4 grid objects under the same date/value.

## IMPORTANT: integrating with your existing code

You already have an existing grid in your application.

You do NOT need to replace that grid.

Add this handler to your existing AG Grid:

```jsx
<AgGridReact
  ...
  onCellClicked={handleMainGridCellClick}
/>
```

Then keep this logic:

```jsx
const handleMainGridCellClick = (params) => {
  if (params?.colDef?.field !== 'cob') {
    return;
  }

  const clickedValue = params.value;

  setSelectedValue(clickedValue);

  const gridsForSelectedValue =
    mockChildGridData[clickedValue] || [];

  setChildGrids(gridsForSelectedValue);
};
```

And render the grids:

```jsx
{childGrids.map((grid, index) => (
  <React.Fragment key={grid.id || index}>
    {renderGridPanel({
      // map your existing grid props here
      title: grid.title,
      data: grid,
    })}
  </React.Fragment>
))}
```

The demo `renderGrid()` in `ClickableGrid5.jsx` is only there to show the
structure. In your actual application, use your existing grid/renderGridPanel
function.

## Later API integration

The mock line:

```js
const gridsForSelectedValue =
  mockChildGridData[clickedValue] || [];
```

can later become:

```js
const response = await getChildGrids(clickedValue);
setChildGrids(response);
```

No change to the `.map()` rendering is required.
