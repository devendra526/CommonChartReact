import React, { useMemo, useState } from 'react';

/*
 * Clickable Grid -> 5 Child Grids
 *
 * HOW TO USE:
 * 1. Replace `mockChildGridData` with your own mock/API data.
 * 2. Pass your existing first-grid rowData and columnDefs to this component.
 * 3. The column configured in CLICKABLE_FIELD will trigger the child grids.
 *
 * Expected child data shape:
 *
 * const mockChildGridData = {
 *   "22 July 2026": [
 *     { id: "grid-1", title: "Grid 1", data: [...], columnDefs: [...] },
 *     { id: "grid-2", title: "Grid 2", data: [...], columnDefs: [...] },
 *     ...
 *   ]
 * };
 *
 * Later, replace getChildGridData() with an API call.
 */

const CLICKABLE_FIELD = 'cob';

// ------------------------------------------------------------
// REPLACE THIS WITH YOUR MOCK DATA
// ------------------------------------------------------------
const mockChildGridData = {
  /*
  "22 July 2026": [
    {
      id: 'grid-1',
      title: 'Grid 1',
      data: [],
      columnDefs: []
    },
    {
      id: 'grid-2',
      title: 'Grid 2',
      data: [],
      columnDefs: []
    },
    {
      id: 'grid-3',
      title: 'Grid 3',
      data: [],
      columnDefs: []
    },
    {
      id: 'grid-4',
      title: 'Grid 4',
      data: [],
      columnDefs: []
    },
    {
      id: 'grid-5',
      title: 'Grid 5',
      data: [],
      columnDefs: []
    }
  ]
  */
};

const getChildGridData = (clickedValue) => {
  return mockChildGridData[clickedValue] || [];
};

// ------------------------------------------------------------
// Simple reusable grid.
// If your project already has a common grid component,
// replace this component with your existing grid component.
// ------------------------------------------------------------
const SimpleGrid = ({ data = [], columnDefs = [] }) => {
  const columns = useMemo(() => {
    if (columnDefs.length) {
      return columnDefs;
    }

    if (!data.length) {
      return [];
    }

    return Object.keys(data[0]).map((field) => ({
      field,
      headerName: field
    }));
  }, [data, columnDefs]);

  return (
    <div className="child-grid-table-wrapper">
      <table className="child-grid-table">
        <thead>
          <tr>
            {columns.map((column) => (
              <th key={column.field}>{column.headerName || column.field}</th>
            ))}
          </tr>
        </thead>

        <tbody>
          {data.map((row, rowIndex) => (
            <tr key={row.id || rowIndex}>
              {columns.map((column) => (
                <td key={column.field}>
                  {row[column.field] ?? ''}
                </td>
              ))}
            </tr>
          ))}

          {!data.length && (
            <tr>
              <td colSpan={Math.max(columns.length, 1)}>
                No data available
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

// ------------------------------------------------------------
// MAIN COMPONENT
// ------------------------------------------------------------
const ClickableGridWithChildGrids = ({
  rowData = [],
  columnDefs = [],
  onCellClicked: externalOnCellClicked
}) => {
  const [selectedCellValue, setSelectedCellValue] = useState(null);
  const [childGrids, setChildGrids] = useState([]);

  const handleCellClicked = (params) => {
    // Only the configured column should open the 5 child grids.
    if (params?.colDef?.field !== CLICKABLE_FIELD) {
      externalOnCellClicked?.(params);
      return;
    }

    const clickedValue = params.value;

    setSelectedCellValue(clickedValue);

    // ----------------------------------------------------------
    // MOCK DATA
    // Later this can become:
    //
    // const response = await fetch(...);
    // const grids = await response.json();
    // ----------------------------------------------------------
    const grids = getChildGridData(clickedValue);

    setChildGrids(grids);

    // Keep your existing cell-click functionality if required.
    externalOnCellClicked?.(params);
  };

  return (
    <div className="clickable-grid-container">
      {/* =====================================================
          EXISTING / MAIN GRID
          ===================================================== */}

      <div className="main-grid-section">
        <div className="main-grid-title">
          Main Grid
        </div>

        <div className="main-grid-table-wrapper">
          <table className="main-grid-table">
            <thead>
              <tr>
                {columnDefs.map((column) => (
                  <th key={column.field}>
                    {column.headerName || column.field}
                  </th>
                ))}
              </tr>
            </thead>

            <tbody>
              {rowData.map((row, rowIndex) => (
                <tr key={row.id || rowIndex}>
                  {columnDefs.map((column) => {
                    const isClickable =
                      column.field === CLICKABLE_FIELD;

                    return (
                      <td
                        key={column.field}
                        className={
                          isClickable
                            ? 'clickable-grid-cell'
                            : ''
                        }
                        onClick={() =>
                          isClickable &&
                          handleCellClicked({
                            value: row[column.field],
                            data: row,
                            colDef: column
                          })
                        }
                      >
                        {row[column.field] ?? ''}
                      </td>
                    );
                  })}
                </tr>
              ))}

              {!rowData.length && (
                <tr>
                  <td colSpan={Math.max(columnDefs.length, 1)}>
                    No data available
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* =====================================================
          SELECTED CELL
          ===================================================== */}

      {selectedCellValue && (
        <div className="selected-cell-info">
          Selected {CLICKABLE_FIELD.toUpperCase()}:{' '}
          <strong>{selectedCellValue}</strong>
        </div>
      )}

      {/* =====================================================
          CHILD GRIDS
          ===================================================== */}

      {childGrids.length > 0 && (
        <div className="child-grids-container">
          {childGrids.map((grid, index) => (
            <section
              className="child-grid-section"
              key={grid.id || index}
            >
              <div className="child-grid-header">
                <h3>{grid.title || `Grid ${index + 1}`}</h3>
              </div>

              <SimpleGrid
                data={grid.data || []}
                columnDefs={grid.columnDefs || []}
              />
            </section>
          ))}
        </div>
      )}
    </div>
  );
};

export default ClickableGridWithChildGrids;
