# Clickable Grid -> 5 Child Grids

## Files

- `ClickableGridWithChildGrids.jsx`
- `clickable-grid-child-grids.css`

## What it does

The `cob` column of the main grid is clickable.

When a COB cell is clicked:

1. The clicked value is stored in `selectedCellValue`.
2. The value is used as a key in `mockChildGridData`.
3. The returned array is rendered using `.map()`.
4. This supports 5 grids, or any number of grids.

## Mock data

Inside `ClickableGridWithChildGrids.jsx`, replace `mockChildGridData` with your data:

```js
const mockChildGridData = {
  "22 July 2026": [
    {
      id: "grid-1",
      title: "Grid 1",
      data: [...],
      columnDefs: [...]
    },
    {
      id: "grid-2",
      title: "Grid 2",
      data: [...],
      columnDefs: [...]
    }
  ]
};
```

## Important

If your project already has an AG Grid/common grid component, you can replace
`SimpleGrid` with your existing grid component. The click/state/child-grid
logic does not depend on the simple table implementation.

For an API later, replace `getChildGridData(clickedValue)` with your API call.
