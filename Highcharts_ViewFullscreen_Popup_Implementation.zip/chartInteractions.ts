// Update your existing CONTEXT_MENU_ITEMS in chartInteractions.ts
// Keep Highcharts native viewFullscreen as the trigger.

export const CONTEXT_MENU_ITEMS = [
  'viewFullscreen',
  'separator',
  'downloadPNG',
  'downloadJPEG',
  'separator',
  'downloadCSV',
  'downloadXLS',
];

// Keep the rest of your existing CHART_INTERACTION_OPTIONS unchanged.
