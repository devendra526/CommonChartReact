# Highcharts native `viewFullscreen` popup-style implementation

This package is specifically for the existing implementation where your
Highcharts menu contains:

    'viewFullscreen'

It does NOT replace the menu with a separate "Expand" button.

## Files

1. `chartInteractions.ts`
   - Keep your existing `viewFullscreen` item.

2. `CommonChartFullscreen.css`
   - Styling for the popup-like fullscreen state.

3. `CommonChart.tsx.snippet`
   - Logic to detect the native Highcharts fullscreen state.
   - Adds a heading and an X close button.
   - Uses `document.exitFullscreen()` when X is clicked.

## Where to make changes in your project

### A. `chartInteractions.ts`

Your existing code already has:

```ts
const CONTEXT_MENU_ITEMS = [
  'viewFullscreen',
  'separator',
  'downloadPNG',
  'downloadJPEG',
  'separator',
  'downloadCSV',
  'downloadXLS',
];
```

KEEP THIS.

Do not remove `viewFullscreen`.

### B. `CommonChart.tsx`

This is the main file to modify.

Your current CommonChart receives:

```tsx
title={window.title}
series={window.series}
```

so you already have the title available.

Add a ref around your `HighchartsReact` component and add the
`fullscreenchange` listener from `CommonChart.tsx.snippet`.

Use your actual title variable where the snippet says:

```ts
titlePropOrWindowTitle
```

For your component it may simply be the `title` prop.

### C. `CommonChart.css`

Copy the contents of:

```text
CommonChartFullscreen.css
```

into your existing `CommonChart.css`, or import it separately.

## Important

The browser Fullscreen API is designed to make the fullscreen element occupy
the fullscreen viewport. CSS can style the element, but browsers can restrict
or normalize some fullscreen geometry.

If you need an absolutely reliable 60% centered popup on Chrome/Edge/VDI,
the better technical implementation is a React fixed-position modal rather
than native fullscreen.

The requested implementation here keeps Highcharts `viewFullscreen` as the
trigger, and adds the heading + close button to that fullscreen state.
